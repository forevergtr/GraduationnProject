<template>
	<view class="page-container">
		<text class="title">就诊�?/text>
		<view class="qrcode-placeholder">
			<text>🔳 这里展示动态就诊二维码</text>
		</view>
	</view>
</template>
<style>
	.page-container { padding: 40rpx; display: flex; flex-direction: column; align-items: center; }
	.title { font-size: 40rpx; font-weight: bold; margin-bottom: 40rpx; margin-top: 100rpx;}
	.qrcode-placeholder { width: 400rpx; height: 400rpx; background: #eee; display: flex; align-items: center; justify-content: center; border-radius: 20rpx; }
</style>
